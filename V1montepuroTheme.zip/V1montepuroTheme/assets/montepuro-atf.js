// Menge erhöhen
document.querySelectorAll('.qty-plus').forEach(btn => {
  btn.addEventListener('click', () => {
    const input = btn.previousElementSibling;
    input.value = parseInt(input.value || 1) + 1;
  });
});

// Menge verringern
document.querySelectorAll('.qty-minus').forEach(btn => {
  btn.addEventListener('click', () => {
    const input = btn.nextElementSibling;
    if (parseInt(input.value) > 1) input.value = parseInt(input.value) - 1;
  });
});

// Add to Cart Logik
document.querySelectorAll('.atc-button').forEach(button => {
  button.addEventListener('click', async (e) => {
    e.preventDefault();
    e.stopPropagation();

    const card = e.target.closest(".variant-card");
    const variantId = card.dataset.id;
    const quantity = card.querySelector(".qty-input").value || 1;

    try {
      const res = await fetch("/cart/add.js", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          items: [{ id: variantId, quantity: parseInt(quantity) }]
        })
      });

      if (res.ok) {
        updateCartCount();
        document.dispatchEvent(new CustomEvent('cart:refresh'));
        console.log("✅ Variante erfolgreich zum Warenkorb hinzugefügt");
      } else {
        console.error("❌ Fehler beim Hinzufügen zum Warenkorb");
      }
    } catch (err) {
      console.error("❌ AJAX Fehler beim Warenkorb-Request:", err);
    }
  });
});

async function updateCartCount() {
  try {
    const res = await fetch('/cart.js');
    const cart = await res.json();
    const count = cart.item_count;
    document.querySelectorAll('hdt-cart-count').forEach(bubble => {
      if (count > 0) {
        bubble.textContent = count;
        bubble.style.display = 'block';
      } else {
        bubble.style.display = 'none';
      }
    });
  } catch (err) {
    console.error('❌ Fehler beim Aktualisieren des Cart-Zählers:', err);
  }
}